import React, {Component} from 'react';
import {BrowserRouter, Switch, Route} from "react-router-dom"
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import Home from "./components/Home";
import NavBar from "./components/NavBar";
import ItemList from "./components/ItemList";
import Item from "./components/Item";
import Cart from "./components/Cart";




export default class App extends Component {
    
    constructor()
    {
        super();
        this.data = [
            {
                id: "1",
                name: "Barbijo",
                price: 150,
                stock: 7,
                description: "Tapabocas protector hecho de lana"
            },
            {
                id: "2",
                name: "Buff",
                price: 200,
                stock: 3,
                description: "Tapabocas protector hecho de nylon. Especial para hacer deporte"
            },
            {
                id: "3",
                name: "Protector de bolsitas",
                price: 350,
                stock: 7,
                description: "Cobertor de bolsitas para dormir hecho de lana"
            },
        ];
    }
    render() {
        return (
            <div className="App container">
                <BrowserRouter>
                    <NavBar/>
                    <Switch>
                        <Route exact path = "/">
                            <Home greeting="Bienvenidos"/>
                            <ItemList data={this.data}/> 
                        </Route>
                        <Route path="/list">
                            <ItemList data={this.data}/>
                        </Route>
                        <Route path="/item/:id">
                            <Item data={this.data}/>
                        </Route>
                        <Route path="/cart">
                            <Cart/>
                        </Route>
                    </Switch>
                
                </BrowserRouter>
            </div>
        );
    }
}

