﻿import React from "react";


const BuyIcon = () => {

    return (
        <button>
            <p>Buy!</p>
        </button>
    )
}

export default BuyIcon