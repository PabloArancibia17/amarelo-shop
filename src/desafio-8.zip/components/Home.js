﻿import React from "react";
import './amarelo.css';
import BuyIcon from "./BuyIcon";


const Home = (props) => {
    return (
        <div>
            
            <hr/>
            <div className="container d-flex justify-content-center">
                <h1 className="myHeader">
                    {props.greeting}!
                </h1>
            </div>
            
            <BuyIcon/>
        </div>

    )
}

export default Home;