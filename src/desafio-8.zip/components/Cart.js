﻿import React from "react";
import cartImg from "../multimedia/cartImg.png";
import {NavLink} from "react-router-dom";


const Cart = () => {
    return (
        <div>
            <h1>
                WELCOME TO THE CART!
            </h1>

        </div>
    )
}

export default Cart;