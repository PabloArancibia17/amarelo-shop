﻿import React from "react";
import cartImg from "../multimedia/cartImg.png";
import {NavLink} from "react-router-dom";


const CartIcon = () => {
    return (
        <div>
            <button>
                <NavLink to={`/cart`}>
                    <img alt="Cart Image" src={cartImg}/>
                </NavLink>
            </button>

        </div>
    )
}

export default CartIcon;