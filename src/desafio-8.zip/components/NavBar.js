﻿import React from 'react';
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import CartIcon from "../components/CartIcon";



const NavBar = () => {
    return (
        <div>
            <Navbar bg="variant" expand="lg">
                <Navbar.Brand href="#home">Amarelo Shop</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="mr-auto">
                        <Nav.Link href="#home">Home</Nav.Link>
                        <Nav.Link href="#aboutUs">About Us</Nav.Link>
                        <Nav.Link href="#aboutUs">Products</Nav.Link>
                    </Nav>
                    <Nav>
                        <CartIcon/>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        </div>
        
    )
}

export default NavBar;