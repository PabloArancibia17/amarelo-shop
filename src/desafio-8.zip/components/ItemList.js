﻿import React from "react";
import {NavLink} from "react-router-dom";

function ItemList(props){
    return <ul>

        {props.data.map(element => <li id={element.id} key={element.id}><NavLink to={`/item/${element.id}`}>{element.name}</NavLink></li>)}
    </ul>
}

export default ItemList